/* ========================================================================
 * PlantUML : a free UML diagram generator
 * ========================================================================
 *
 * (C) Copyright 2009-2020, Arnaud Roques
 *
 * Project Info:  https://plantuml.com
 * 
 * If you like this project or if you find it useful, you can support us at:
 * 
 * https://plantuml.com/patreon (only 1$ per month!)
 * https://plantuml.com/paypal
 * 
 * This file is part of PlantUML.
 *
 * Licensed under The MIT License (Massachusetts Institute of Technology License)
 * 
 * See http://opensource.org/licenses/MIT
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * 
 *
 * Original Author:  Arnaud Roques
 */
package net.sourceforge.plantuml;

import net.sourceforge.plantuml.style.SName;

public enum UmlDiagramType {
	SEQUENCE, STATE, CLASS, OBJECT, ACTIVITY, DESCRIPTION, COMPOSITE, FLOW, TIMING, BPM, NWDIAG, MINDMAP, WBS, WIRE,
	HELP, GANTT, SALT, JSON, GIT, BOARD, YAML;

	public SName getStyleName() {
		if (this == SEQUENCE) {
			return SName.sequenceDiagram;
		}
		if (this == STATE) {
			return SName.stateDiagram;
		}
		if (this == CLASS) {
			return SName.classDiagram;
		}
		if (this == OBJECT) {
			return SName.objectDiagram;
		}
		if (this == ACTIVITY) {
			return SName.activityDiagram;
		}
		if (this == DESCRIPTION) {
			return SName.componentDiagram;
		}
		if (this == COMPOSITE) {
			return SName.componentDiagram;
		}
		if (this == MINDMAP) {
			return SName.mindmapDiagram;
		}
		if (this == WBS) {
			return SName.wbsDiagram;
		}
		if (this == GANTT) {
			return SName.ganttDiagram;
		}
		if (this == SALT) {
			return SName.saltDiagram;
		}
		if (this == YAML) {
			return SName.yamlDiagram;
		}
		if (this == JSON) {
			return SName.jsonDiagram;
		}
		return SName.activityDiagram;
	}
}
