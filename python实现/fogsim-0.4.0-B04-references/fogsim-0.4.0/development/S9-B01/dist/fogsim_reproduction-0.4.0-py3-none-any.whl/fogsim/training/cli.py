"""Independent fogsim-train entry point. B01 implements validate/evaluate only."""
import argparse
import json
from pathlib import Path
from fogsim.errors import InputError
from fogsim.rules.factory import prepare_rules
from fogsim.rules.specs import RuleSpec
from .config import load_training_config
from .plans import build_training_plans, parse_training_plan
from .evaluation import evaluate_rule_pair
from .protocols import read_json, write_json, empty_output


def main(argv=None):
    parser = argparse.ArgumentParser(prog="fogsim-train")
    sub = parser.add_subparsers(dest="command", required=True)
    validate = sub.add_parser("validate", help="preflight and freeze all plans, without simulation")
    validate.add_argument("--config", required=True)
    validate.add_argument("--output", required=True)
    evaluate = sub.add_parser("evaluate", help="evaluate an explicit fixed rule pair on one frozen plan")
    evaluate.add_argument("--rules", required=True)
    evaluate.add_argument("--plan", required=True)
    evaluate.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "validate":
            cfg = load_training_config(args.config)
            plans = build_training_plans(cfg)
            output = empty_output(args.output)
            write_json(output / "resolved_config.json", cfg.to_dict())
            for g, plan in enumerate(plans.training):
                write_json(output / f"plans/train-{g:04d}.json", plan.to_dict())
            write_json(output / "plans/validation.json", plans.validation.to_dict())
            write_json(output / "plans/test.json", plans.test.to_dict())
            resolved = cfg.to_dict()
            count = sum(len(p.to_dict()["entries"]) for p in plans.training)
            estimate = count * resolved["evolution"]["population_size"] * len(resolved["trials"]["evolution_seeds"])
            summary = dict(status="PREFLIGHT_ONLY", simulations_executed=0, training_simulation_upper_bound=estimate,
                deferred="candidate validation, final test and evolution are implemented in B02/B03",
                event_budgets=[e["effective_config"].get("run", {}).get("max_events") for p in plans.all_plans() for e in p.to_dict()["entries"]],
                plan_ids=[p.plan_id for p in plans.all_plans()])
            write_json(output / "preflight.json", summary)
            print(json.dumps(summary))
            return 0
        rules = read_json(args.rules)
        from fogsim.instances.fixed import object_fields
        object_fields(rules, ("routing", "sequencing"), where="fixed-rule-pair")
        prepared = prepare_rules(RuleSpec.from_mapping("routing", rules["routing"]),
                                 RuleSpec.from_mapping("sequencing", rules["sequencing"]))
        plan = parse_training_plan(read_json(args.plan))
        result = evaluate_rule_pair(prepared, plan, args.output).to_dict()
        print(json.dumps({k: result[k] for k in ("evaluation_id", "status", "fitness", "completed_runs")}))
        return 0 if result["status"] == "FEASIBLE" else 1 if result["status"] == "INFEASIBLE" else 130
    except InputError as exc:
        parser.exit(2, f"configuration/input error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
